﻿using RestAPI_DocSolutions.Models;
using RestAPI_DocSolutions.Services;
using System.Data.SqlClient;
using System.Data;

namespace RestAPI_DocSolutions.Repository
{
    public class EmpleadoRepository : IEmpleadoRepository
    {
        private readonly DataDBContext _dBContext;
        public EmpleadoRepository(DataDBContext dBContext)
        {
            _dBContext = dBContext;
        }
        public async Task<Empleados> CreateEmpleado(Empleados empleado)
        {
            var connString = _dBContext.GetConnectionString();
            using (SqlConnection connection = new SqlConnection(connString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand("InsertarEmpleado", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Usuario", empleado.Usuario);
                    command.Parameters.AddWithValue("@Nombre", empleado.Nombre);
                    command.Parameters.AddWithValue("@APaterno", empleado.APaterno);
                    command.Parameters.AddWithValue("@AMaterno", empleado.AMaterno);
                    command.Parameters.AddWithValue("@Telefono", empleado.Telefono);
                    command.Parameters.AddWithValue("@CorreoElectronico", empleado.CorreoElectronico);
                    command.Parameters.AddWithValue("@Puesto", empleado.Puesto);
                    command.Parameters.AddWithValue("@FechaIngreso", empleado.FechaIngreso);
                    command.Parameters.AddWithValue("@Password", empleado.Password);

                    int rowsAffected = await Task.Run(() => command.ExecuteNonQuery());
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            empleado.Id = (int)reader.GetDecimal(reader.GetOrdinal("IdEmpleado"));
                        }
                    }
                }
            }

            return empleado;
        }

        public async Task<List<Empleados>> GetByName(string name)
        {
            List<Empleados> empleados = new List<Empleados>();
            using (SqlConnection connection = new SqlConnection(_dBContext.GetConnectionString()))
            {
                await connection.OpenAsync();

                using (SqlCommand command = new SqlCommand("SeleccionNombre", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Nombre", name);

                    int rowsAffected = command.ExecuteNonQuery();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string restValue = reader.GetString("Nombre");
                            var item = new Empleados()
                            {
                                Nombre = restValue,
                            };
                            empleados.Add(item);
                        }
                    }
                }
            }

            return empleados;
        }
    }
}
