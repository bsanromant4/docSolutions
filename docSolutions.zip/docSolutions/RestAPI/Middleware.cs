﻿using Microsoft.AspNetCore.Diagnostics;
using System.Net;
using System.Text.Json;

namespace RestAPI_DocSolutions
{
    public static class Middleware
    {
        public static void Configure(IApplicationBuilder app)
        {
            app.UseExceptionHandler(errorApp =>
            {
                errorApp.Run(async context =>
                {
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    context.Response.ContentType = "application/json";

                    var errorfeat = context.Features.Get<IExceptionHandlerFeature>();
                    if (errorfeat != null)
                    {
                        var exceptionError = errorfeat.Error;
                        var errorResponse = new
                        {
                            error = "Se ha producido un error",
                            message = exceptionError.Message,
                        };

                        var jsonResponse = JsonSerializer.Serialize(errorResponse);
                        await context.Response.WriteAsync(jsonResponse);
                    }
                });
            });
        }
    }
}
