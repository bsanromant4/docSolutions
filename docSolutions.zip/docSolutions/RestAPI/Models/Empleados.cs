﻿using System.ComponentModel.DataAnnotations;

namespace RestAPI_DocSolutions.Models
{
    public class Empleados
    {
        public int Id { get; set; }
        [Required (ErrorMessage = "Es necesario el campo Usuario")]
        public string Usuario { get; set; } = string.Empty;
        [Required(ErrorMessage = "Es necesario el campo Nombre")]
        public string Nombre { get; set; } = string.Empty;
        [Required(ErrorMessage = "Es necesario el campo APaterno")]
        public string APaterno { get; set; } = string.Empty;
        [Required(ErrorMessage = "Es necesario el campo AMaterno")]
        public string AMaterno { get; set; } = string.Empty;
        [Required(ErrorMessage = "Es necesario el campo Telefono")]
        public string Telefono { get; set; } = string.Empty;
        [Required(ErrorMessage = "Es necesario el campo Correo Electronico")]
        public string CorreoElectronico { get; set; } = string.Empty;
        [Required(ErrorMessage = "Es necesario el campo Puesto")]
        public string Puesto { get; set; } = string.Empty;
        [Required(ErrorMessage = "Es necesario el campo Fecha Ingreso")]
        public DateTime FechaIngreso { get; set; }
        [Required(ErrorMessage = "Es necesario el campo Password")]
        public string Password { get; set; } = string.Empty;
    }
}
