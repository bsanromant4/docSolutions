﻿using RestAPI_DocSolutions.Models;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace RestAPI_DocSolutions.Helper
{
    public static class GlobalHelper
    {
        public static void ValidaModelo(Empleados empleados)
        {
            if (empleados != null) { 
                if(empleados?.FechaIngreso >= DateTime.Now)
                {
                    throw new Exception("La fecha de ingreso no puede ser mayor a la fecha actual");
                }

                if (!string.IsNullOrEmpty(empleados?.Telefono))
                {
                    Regex regex = new Regex(@"^\d{10}$");
                    if (!regex.IsMatch(empleados?.Telefono))
                    {
                        throw new Exception("El número telefonico ingresado no es correcto");
                    }
                }

                if (!string.IsNullOrEmpty(empleados?.CorreoElectronico))
                {
                    // Patrón de expresión regular para validar correos electrónicos
                    string pattern = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";

                    // Crear un objeto Regex con el patrón
                    Regex regex = new Regex(pattern);

                    // Validar el correo electrónico usando el método IsMatch
                    if (!regex.IsMatch(empleados?.CorreoElectronico))
                    {
                        throw new Exception("Correo Electronico No Válido");
                    }
                }
            }
        }

        public static string HashPassword(string password)
        {
            byte[] salt = GenerateSalt();

            Rfc2898DeriveBytes pbkdf2 = new Rfc2898DeriveBytes(password, salt, 10000);

            // Obtener el hash de la contraseña
            byte[] hash = pbkdf2.GetBytes(32); // 32 bytes para un hash de 256 bits

            // Convertir el hash y la sal a cadenas base64 para su almacenamiento
            string hashBase64 = Convert.ToBase64String(hash);
            string saltBase64 = Convert.ToBase64String(salt);

            // Devolver la concatenación del hash y la sal, separados por un carácter especial
            return $"{hashBase64}:{saltBase64}";
        }

        static byte[] GenerateSalt()
        {
            // Generar una sal aleatoria de 16 bytes (128 bits)
            byte[] salt = new byte[16];
            using (var rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(salt);
            }
            return salt;
        }
    }
}
