using Microsoft.AspNetCore.Mvc;
using RestAPI_DocSolutions.Models;
using RestAPI_DocSolutions.Services;

namespace RestAPI_DocSolutions.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmpleadoController : ControllerBase
    {
        private readonly ILogger<WeatherForecastController> _logger;
        private IEmpleadoService _service;

        public EmpleadoController(ILogger<WeatherForecastController> logger, IEmpleadoService empleadoService)
        {
            _logger = logger;
            _service = empleadoService;
        }

        [HttpGet]
        public ActionResult<Empleados> GetByName([FromQuery] string name)
        {
            var result = _service.GetByName(name);
            return Ok(result);
        }

        [HttpPost]
        public ActionResult<Empleados> CreateUser([FromBody] Empleados payload)
        {
            var result = _service.CreateEmpleado(payload);
            return Ok(result);
        }
    }
}
