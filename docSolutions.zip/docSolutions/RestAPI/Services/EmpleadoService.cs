﻿using RestAPI_DocSolutions.Helper;
using RestAPI_DocSolutions.Models;

namespace RestAPI_DocSolutions.Services
{
    public class EmpleadoService : IEmpleadoService
    {
        private readonly IEmpleadoRepository _repository;
        public EmpleadoService(IEmpleadoRepository repository)
        {
            _repository = repository;
        }

        public async Task<Empleados> CreateEmpleado(Empleados empleado)
        {
            GlobalHelper.ValidaModelo(empleado);
            empleado.Password = GlobalHelper.HashPassword(empleado.Password);
            empleado = await _repository.CreateEmpleado(empleado);
            return empleado;
        }

        public async Task<List<Empleados>> GetByName(string name)
        {
            var empleados = await _repository.GetByName(name);
            return empleados;
        }
    }
}
