﻿using RestAPI_DocSolutions.Models;

namespace RestAPI_DocSolutions.Services
{
    public interface IEmpleadoService
    {
        Task<List<Empleados>> GetByName(string name);
        Task<Empleados> CreateEmpleado(Empleados empleado);
    }
}
