USE [BD_Backend]
GO

/****** Object:  StoredProcedure [dbo].[InsertarEmpleado]    Script Date: 08/03/2024 02:50:09 p. m. ******/
DROP PROCEDURE [dbo].[InsertarEmpleado]
GO

/****** Object:  StoredProcedure [dbo].[InsertarEmpleado]    Script Date: 08/03/2024 02:50:09 p. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[InsertarEmpleado]
	@Id int,
	@Usuario NVARCHAR(50),
    @Nombre NVARCHAR(50),
    @APaterno NVARCHAR(80),
	@AMaterno NVARCHAR(80),
	@Telefono NVARCHAR(15),
	@CorreoElectronico NVARCHAR(100),
	@Puesto NVARCHAR(50),
    @FechaIngreso DATETIME,
    @Password NVARCHAR(max)
AS
BEGIN
    BEGIN TRANSACTION;

    BEGIN TRY
        INSERT INTO [dbo].[Empleado]
           ([Usuario]
           ,[Nombre]
           ,[APaterno]
           ,[AMaterno]
           ,[Telefono]
           ,[CorreoElectronico]
           ,[Puesto]
           ,[FechaIngreso]
           ,[Password])
     VALUES
           (@Usuario
           ,@Nombre
           ,@APaterno
           ,@AMaterno
           ,@Telefono
           ,@CorreoElectronico
           ,@Puesto
           ,@FechaIngreso
           ,@Password)

		select @@IDENTITY as 'IdEmpleado'

        -- Commit de la transacci�n si todo ha ido bien
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        -- Rollback de la transacci�n si hay alg�n error
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO


