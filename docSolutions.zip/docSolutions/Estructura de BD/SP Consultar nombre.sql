USE [BD_Backend]
GO

/****** Object:  StoredProcedure [dbo].[SeleccionNombre]    Script Date: 08/03/2024 02:50:42 p. m. ******/
DROP PROCEDURE [dbo].[SeleccionNombre]
GO

/****** Object:  StoredProcedure [dbo].[SeleccionNombre]    Script Date: 08/03/2024 02:50:42 p. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SeleccionNombre](@Nombre nvarchar(50))
AS
BEGIN
	SELECT * FROM Empleado (nolock) WHERE Nombre like '%'+ @Nombre +'%'
END
GO


